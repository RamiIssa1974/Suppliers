﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SupplierPortalAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddUsersAndRoles2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                column: "PasswordHash",
                value: "$2a$11$az2ymLN/apHBsb/i0szfieOahQgyYSbheVvO5xl9z0Cs.zZHbogUu");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "PasswordHash", "RoleId" },
                values: new object[] { "$2a$11$B.pKJNg7Gc3N8qeSpC7nfezNkzVSB0m15tZ1sZZIvA.m/7jD9GRFm", 2 });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 3,
                column: "PasswordHash",
                value: "$2a$11$Alyb77s/uWBMH7N3.O633O2SFvz6XlWz0drjLm7DVFengWzPayFE2");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                column: "PasswordHash",
                value: "$2a$11$PVoAlG/os4J5gk/Mcg4iweAq/PCSa3FTsXioNyDcIjlQGUZ01bK5m");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "PasswordHash", "RoleId" },
                values: new object[] { "$2a$11$SrcK6K1aUzudZOVudi/OLeMntDW9VamUG2hIc8Aoje3V4rpUk6UWC", 1 });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 3,
                column: "PasswordHash",
                value: "$2a$11$kU8noZ3KhG6rcSOYIj5GMOxjpQKP.Ynva0usRwZy1fIFbDXTqr1.u");
        }
    }
}
