﻿namespace SuppliersWebApp.ViewModels
{
    public class DashboardViewModel
    {
        public int TotalSuppliers { get; set; }
        public int TotalOrders { get; set; }
        public List<string> RecentActivities { get; set; }
    }
}