﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SuppliersWebApp.ViewModels;

namespace SuppliersWebApp.Controllers
{
    public class DashboardController : Controller
    {
        private readonly HttpClient _httpClient;
        public DashboardController(IHttpClientFactory clientFactory)
        {            
            _httpClient = clientFactory.CreateClient("SupplierPortalAPI");
        }

        public async Task<IActionResult> Index()
        {

            // Example data for the dashboard
            var dashboardData = await GetVm();

            return View(dashboardData);
        }

        public async Task<DashboardViewModel> GetVm()
        {
            var totalSuppliersResponse = await _httpClient.GetAsync("api/suppliers/totalsuppliers");
            var totalOrdersResponse = await _httpClient.GetAsync("api/orders/totalorders");
            var recentActivitiesResponse = await _httpClient.GetAsync("api/suppliers/recentactivities");

            var totalSuppliers = int.Parse(await totalSuppliersResponse.Content.ReadAsStringAsync());
            var totalOrders = int.Parse(await totalOrdersResponse.Content.ReadAsStringAsync());
            var recentActivities = JsonConvert.DeserializeObject<List<string>>(await recentActivitiesResponse.Content.ReadAsStringAsync());
            var dashboardData = new DashboardViewModel
            {
                TotalSuppliers = totalSuppliers,
                TotalOrders = totalOrders,
                RecentActivities = recentActivities
            };
            return dashboardData;

        }
    }

}
