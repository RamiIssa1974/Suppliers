﻿using DataModels.Models.DAL;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace SuppliersWebApp.Controllers
{
    public class OrdersController : Controller
    {
        private readonly HttpClient _httpClient;

        public OrdersController(IHttpClientFactory clientFactory)
        {
            _httpClient = clientFactory.CreateClient("SupplierPortalAPI");
        }
        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetAsync("api/orders");

            if (response.IsSuccessStatusCode)
            {
                // Read the response content as a string and deserialize it using Newtonsoft.Json
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var orders = JsonConvert.DeserializeObject<List<Order>>(jsonResponse);

                return View(orders);
            }

            return View(new List<Order>());
        }

        // Display the confirmation page for deleting an order
        public async Task<IActionResult> Delete(int id)
        {
            // Fetch order details for confirmation (optional)
            var response = await _httpClient.GetAsync($"api/orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<Order>(jsonResponse);
                return View(order);
            }

            return NotFound(); // Handle case where order doesn't exist
        }

        // Handle the POST request to delete the order
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"api/orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                // Handle error scenario
                
                var getResponse = await _httpClient.GetAsync($"api/orders/{id}");
                if (getResponse.IsSuccessStatusCode)
                {
                    var jsonResponse = await getResponse.Content.ReadAsStringAsync();
                    var order = JsonConvert.DeserializeObject<Order>(jsonResponse);
                    ModelState.AddModelError("", "An error occurred while attempting to delete the order.");
                    return View("Delete", order);                   
                }               
            }
            ModelState.AddModelError("", "Failed to delete order.");
            return View("Delete");
        }

        // Display the edit form with the order's current details
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetAsync($"api/orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<Order>(jsonResponse);
                return View(order);
            }

            return NotFound(); // Handle case where order doesn't exist
        }

        // Handle the form submission to update the order
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Order order)
        {
            if (ModelState.IsValid)
            {
                var content = new StringContent(JsonConvert.SerializeObject(order), System.Text.Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"api/orders/{order.OrderId}", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError("", "Failed to update order.");
            }

            return View(order);
        }

        // Display the empty form for creating a new order
        public IActionResult Create()
        {
            return View();
        }

        // Handle the form submission to create a new order
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Order order)
        {
            if (ModelState.IsValid)
            {
                var content = new StringContent(JsonConvert.SerializeObject(order), System.Text.Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("api/orders", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError("", "Failed to create order.");
            }

            return View(order);
        }

    }
}
