﻿using DataModels.Models.DAL;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace SuppliersWebApp.Controllers
{
    public class SuppliersController : Controller
    {
        private readonly HttpClient _httpClient;

        public SuppliersController(IHttpClientFactory clientFactory)
        {
            _httpClient = clientFactory.CreateClient("SupplierPortalAPI");
        }
        public async Task<IActionResult> Index()
        {
            var token = HttpContext.Session.GetString("JwtToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync("api/suppliers");

            if (response.IsSuccessStatusCode)
            {
                // Read the response content as a string and deserialize it using Newtonsoft.Json
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(jsonResponse);

                return View(suppliers);
            }

            return View(new List<Supplier>());
        }

        // Display the confirmation page for deleting a supplier
        public async Task<IActionResult> Delete(int id)
        {
            // Fetch supplier details for confirmation (optional)
            var response = await _httpClient.GetAsync($"api/suppliers/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var supplier = JsonConvert.DeserializeObject<Supplier>(jsonResponse);
                return View(supplier);
            }

            return NotFound(); // Handle case where supplier doesn't exist
        }

        // Handle the POST request to delete the supplier
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"api/suppliers/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                // Handle error scenario
                
                var getResponse = await _httpClient.GetAsync($"api/suppliers/{id}");
                if (getResponse.IsSuccessStatusCode)
                {
                    var jsonResponse = await getResponse.Content.ReadAsStringAsync();
                    var supplier = JsonConvert.DeserializeObject<Supplier>(jsonResponse);
                    ModelState.AddModelError("", "An error occurred while attempting to delete the supplier.");
                    return View("Delete", supplier);                   
                }               
            }
            ModelState.AddModelError("", "Failed to delete supplier.");
            return View("Delete");
        }

        // Display the edit form with the supplier's current details
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetAsync($"api/suppliers/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var supplier = JsonConvert.DeserializeObject<Supplier>(jsonResponse);
                return View(supplier);
            }

            return NotFound(); // Handle case where supplier doesn't exist
        }

        // Handle the form submission to update the supplier
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Supplier supplier)
        {
            if (ModelState.IsValid)
            {
                var content = new StringContent(JsonConvert.SerializeObject(supplier), System.Text.Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"api/suppliers/{supplier.SupplierID}", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError("", "Failed to update supplier.");
            }

            return View(supplier);
        }

        // Display the empty form for creating a new supplier
        public IActionResult Create()
        {
            return View();
        }

        // Handle the form submission to create a new supplier
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Supplier supplier)
        {
            if (ModelState.IsValid)
            {
                var content = new StringContent(JsonConvert.SerializeObject(supplier), System.Text.Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("api/suppliers", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError("", "Failed to create supplier.");
            }

            return View(supplier);
        }

    }
}
