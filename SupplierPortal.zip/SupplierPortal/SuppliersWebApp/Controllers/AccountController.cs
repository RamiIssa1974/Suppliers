﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SuppliersWebApp.ViewModels;

public class AccountController : Controller
{
    private readonly HttpClient _httpClient;

    public AccountController(IHttpClientFactory clientFactory)
    {
        _httpClient = clientFactory.CreateClient("SupplierPortalAPI");
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var loginDto = new
        {
            Username = model.Username,
            Password = model.Password
        };

        var response = await _httpClient.PostAsJsonAsync("api/auth/login", loginDto);

        if (response.IsSuccessStatusCode)
        {
            var result = await response.Content.ReadAsStringAsync();
            var loginResponse = JsonConvert.DeserializeObject<LoginResponse>(result); // Use DTO
            var token = loginResponse?.Token;
            var userRole = loginResponse?.Role;

            // Store the token in a secure cookie or session
            HttpContext.Session.SetString("JwtToken", (string)token);
            HttpContext.Session.SetString("UserRole", userRole);

            return RedirectToAction("Index", "Home");
        }

        ModelState.AddModelError("", "Invalid username or password");
        return View(model);
    }

    [HttpGet]
    public IActionResult Logout()
    {
        HttpContext.Session.Remove("JwtToken");
        return RedirectToAction("Login");
    }
}

public class LoginResponse
{
    public string Token { get; set; }
    public string Role { get; set; }
}
