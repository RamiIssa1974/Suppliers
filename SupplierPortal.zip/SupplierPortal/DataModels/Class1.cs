﻿namespace DataModels
{
    public class Class1
    {

    }
}
