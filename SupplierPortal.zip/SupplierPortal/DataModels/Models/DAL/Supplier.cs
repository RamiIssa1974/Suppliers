﻿using System.ComponentModel.DataAnnotations;

namespace DataModels.Models.DAL
{
    public class Supplier
    {
        public int SupplierID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [Phone]
        public string Phone { get; set; }
        public string Address { get; set; }
    }
}
